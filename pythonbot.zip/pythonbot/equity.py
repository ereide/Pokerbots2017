import subprocess
import sys
#import ../pythonbot/pbots_calc-master/example/calculator.sh
def run_equity():#hand,hand,board):
    #subprocess.hand[0],hand[1]
    #value = subprocess.call(["print swag"])
    #print value
   # value=subprocess.call(["ls", "-l"])
#    value=subprocess.check_output(["ls"])
    output = subprocess.call(" ./pbots_calc-master/python/calculator.sh 4hqd:js9h askcqh",shell=True)

    return output


#if run_equity()==0:
 #   print True
print run_equity()
#print("SWAG")
