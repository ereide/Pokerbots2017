python Player.py "$@"
