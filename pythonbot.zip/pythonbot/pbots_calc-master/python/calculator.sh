#!/bin/sh
export DYLD_LIBRARY_PATH=/Users/phuvp/IAP/pokerbot/Pokerbots2017/pythonbot/pbots_calc-master/export/darwin/lib:$LD_LIBRARY_PATH
python /Users/phuvp/IAP/pokerbot/Pokerbots2017/pythonbot/pbots_calc-master/python/calculator.py $@